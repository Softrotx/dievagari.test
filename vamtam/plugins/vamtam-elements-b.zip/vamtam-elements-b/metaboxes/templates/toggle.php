<?php
/**
 * on/off toggle
 */

$option  = $value;
$checked = vamtam_sanitize_bool( $default );

$ff = empty( $field_filter ) ? '' : 'data-field-filter="' . esc_attr( $field_filter ) . '"';
?>

<div class="vamtam-config-row toggle <?php echo esc_attr( $class ) ?> clearfix" <?php echo $ff // xss ok ?>>
	<div class="rtitle">
		<h4><?php echo esc_html( $name ) ?></h4>
	</div>

	<div class="rcontent clearfix">
		<?php include VAMTAMAC_B_DIR . 'templates/toggle-basic.php' ?>
	</div>
</div>
