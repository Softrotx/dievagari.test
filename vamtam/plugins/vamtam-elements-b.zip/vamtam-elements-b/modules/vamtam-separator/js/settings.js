(function($){

	FLBuilder.registerModuleHelper('separator', {

		rules: {
			height: {
				required: true,
				number: true
			}
		}
	});

})(jQuery);
