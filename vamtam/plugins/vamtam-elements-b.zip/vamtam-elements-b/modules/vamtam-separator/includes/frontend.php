<div class="fl-separator" style="border-top-color:<?php echo esc_attr( vamtam_el_sanitize_accent( $settings->color ) )?>;opacity:<?php echo esc_attr( $settings->opacity ) ?>"></div>
