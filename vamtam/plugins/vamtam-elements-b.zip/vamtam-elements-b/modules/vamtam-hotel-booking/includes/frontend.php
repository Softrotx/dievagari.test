<?php

FLBuilderModel::default_settings( $settings, array(
	'post_type' => 'hb_room',
) );

FLBuilder::render_module_html( 'vamtam-blog', $settings );
