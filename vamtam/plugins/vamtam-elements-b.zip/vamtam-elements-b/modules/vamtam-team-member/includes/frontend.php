<?php

include locate_template( 'templates/beaver/vamtam-team-member.php' );
