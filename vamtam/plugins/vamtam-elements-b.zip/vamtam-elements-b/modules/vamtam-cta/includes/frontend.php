<?php

include locate_template( 'templates/beaver/vamtam-cta.php' );
